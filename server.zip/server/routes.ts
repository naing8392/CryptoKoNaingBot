import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSimulationSessionSchema, insertScenarioAnalysisSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Simulation Sessions
  app.post("/api/simulation-sessions", async (req, res) => {
    try {
      const validatedData = insertSimulationSessionSchema.parse(req.body);
      const session = await storage.createSimulationSession(validatedData);
      res.json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create simulation session" });
      }
    }
  });

  app.get("/api/simulation-sessions/:id", async (req, res) => {
    try {
      const session = await storage.getSimulationSession(req.params.id);
      if (!session) {
        res.status(404).json({ message: "Simulation session not found" });
        return;
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to get simulation session" });
    }
  });

  app.put("/api/simulation-sessions/:id", async (req, res) => {
    try {
      const session = await storage.updateSimulationSession(req.params.id, req.body);
      if (!session) {
        res.status(404).json({ message: "Simulation session not found" });
        return;
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to update simulation session" });
    }
  });

  app.delete("/api/simulation-sessions/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteSimulationSession(req.params.id);
      if (!deleted) {
        res.status(404).json({ message: "Simulation session not found" });
        return;
      }
      res.json({ message: "Simulation session deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete simulation session" });
    }
  });

  // Scenario Analyses
  app.post("/api/scenario-analyses", async (req, res) => {
    try {
      const validatedData = insertScenarioAnalysisSchema.parse(req.body);
      const analysis = await storage.createScenarioAnalysis(validatedData);
      res.json(analysis);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create scenario analysis" });
      }
    }
  });

  app.get("/api/scenario-analyses", async (req, res) => {
    try {
      const analyses = await storage.getAllScenarioAnalyses();
      res.json(analyses);
    } catch (error) {
      res.status(500).json({ message: "Failed to get scenario analyses" });
    }
  });

  app.get("/api/scenario-analyses/:id", async (req, res) => {
    try {
      const analysis = await storage.getScenarioAnalysis(req.params.id);
      if (!analysis) {
        res.status(404).json({ message: "Scenario analysis not found" });
        return;
      }
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to get scenario analysis" });
    }
  });

  app.delete("/api/scenario-analyses/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteScenarioAnalysis(req.params.id);
      if (!deleted) {
        res.status(404).json({ message: "Scenario analysis not found" });
        return;
      }
      res.json({ message: "Scenario analysis deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete scenario analysis" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
