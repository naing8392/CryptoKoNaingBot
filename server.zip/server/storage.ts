import { type SimulationSession, type InsertSimulationSession, type ScenarioAnalysis, type InsertScenarioAnalysis } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Simulation Sessions
  createSimulationSession(session: InsertSimulationSession): Promise<SimulationSession>;
  getSimulationSession(id: string): Promise<SimulationSession | undefined>;
  updateSimulationSession(id: string, updates: Partial<SimulationSession>): Promise<SimulationSession | undefined>;
  deleteSimulationSession(id: string): Promise<boolean>;
  
  // Scenario Analyses
  createScenarioAnalysis(analysis: InsertScenarioAnalysis): Promise<ScenarioAnalysis>;
  getScenarioAnalysis(id: string): Promise<ScenarioAnalysis | undefined>;
  getAllScenarioAnalyses(): Promise<ScenarioAnalysis[]>;
  deleteScenarioAnalysis(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private simulationSessions: Map<string, SimulationSession>;
  private scenarioAnalyses: Map<string, ScenarioAnalysis>;

  constructor() {
    this.simulationSessions = new Map();
    this.scenarioAnalyses = new Map();
  }

  // Simulation Sessions
  async createSimulationSession(insertSession: InsertSimulationSession): Promise<SimulationSession> {
    const id = randomUUID();
    const session: SimulationSession = {
      startingBankroll: insertSession.startingBankroll,
      currentBankroll: insertSession.currentBankroll,
      baseBet: insertSession.baseBet,
      currentStep: insertSession.currentStep ?? 1,
      totalRounds: insertSession.totalRounds ?? 0,
      totalWagered: insertSession.totalWagered ?? 0,
      netProfit: insertSession.netProfit ?? 0,
      maxDrawdown: insertSession.maxDrawdown ?? 0,
      gameType: insertSession.gameType ?? "roulette",
      payoutRatio: insertSession.payoutRatio ?? 2.0,
      winProbability: insertSession.winProbability ?? 0.4865,
      results: (insertSession.results || []) as Array<{
        round: number;
        bet: number;
        outcome: 'win' | 'loss';
        bankroll: number;
        step: number;
      }>,
      id,
      createdAt: new Date(),
    };
    this.simulationSessions.set(id, session);
    return session;
  }

  async getSimulationSession(id: string): Promise<SimulationSession | undefined> {
    return this.simulationSessions.get(id);
  }

  async updateSimulationSession(id: string, updates: Partial<SimulationSession>): Promise<SimulationSession | undefined> {
    const session = this.simulationSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.simulationSessions.set(id, updatedSession);
    return updatedSession;
  }

  async deleteSimulationSession(id: string): Promise<boolean> {
    return this.simulationSessions.delete(id);
  }

  // Scenario Analyses
  async createScenarioAnalysis(insertAnalysis: InsertScenarioAnalysis): Promise<ScenarioAnalysis> {
    const id = randomUUID();
    const analysis: ScenarioAnalysis = {
      ...insertAnalysis,
      id,
      createdAt: new Date(),
      results: (insertAnalysis.results || []) as Array<{
        round: number;
        bet: number;
        outcome: 'win' | 'loss';
        bankroll: number;
        step: number;
      }>,
    };
    this.scenarioAnalyses.set(id, analysis);
    return analysis;
  }

  async getScenarioAnalysis(id: string): Promise<ScenarioAnalysis | undefined> {
    return this.scenarioAnalyses.get(id);
  }

  async getAllScenarioAnalyses(): Promise<ScenarioAnalysis[]> {
    return Array.from(this.scenarioAnalyses.values());
  }

  async deleteScenarioAnalysis(id: string): Promise<boolean> {
    return this.scenarioAnalyses.delete(id);
  }
}

export const storage = new MemStorage();
