import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

interface BankrollChartProps {
  data: Array<{
    round: number;
    bankroll: number;
    profit: number;
  }>;
  title?: string;
  className?: string;
}

export default function BankrollChart({ data, title = "Bankroll History", className }: BankrollChartProps) {
  const chartData = data.map(item => ({
    round: item.round,
    bankroll: item.bankroll,
    profit: item.profit,
  }));

  return (
    <Card className={className} data-testid="bankroll-chart">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="round" 
                className="text-xs text-muted-foreground"
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                className="text-xs text-muted-foreground"
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `$${value.toFixed(0)}`}
              />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
                        <p className="font-medium">Round {label}</p>
                        <p className="text-primary">
                          Bankroll: ${typeof payload[0]?.value === 'number' ? payload[0].value.toFixed(2) : '0.00'}
                        </p>
                        <p className={`${(payload[1]?.value as number) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          Profit: ${typeof payload[1]?.value === 'number' ? payload[1].value.toFixed(2) : '0.00'}
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Line 
                type="monotone" 
                dataKey="bankroll" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={false}
                name="Bankroll"
              />
              <Line 
                type="monotone" 
                dataKey="profit" 
                stroke="hsl(var(--accent))" 
                strokeWidth={2}
                dot={false}
                name="Profit"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
