import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RotateCcw, Settings, Play, Square } from "lucide-react";
import { simulateBetting } from "@/lib/betting-calculator";
import BankrollChart from "./bankroll-chart";

interface SimulationState {
  bankroll: number;
  currentBet: number;
  currentStep: number;
  totalRounds: number;
  results: Array<{
    round: number;
    bet: number;
    outcome: 'win' | 'loss';
    bankroll: number;
    step: number;
    profit: number;
  }>;
}

export default function BettingSimulator() {
  const [simulation, setSimulation] = useState<SimulationState>({
    bankroll: 1000,
    currentBet: 10,
    currentStep: 1,
    totalRounds: 0,
    results: [],
  });

  const [settings] = useState({
    baseBet: 10,
    startingBankroll: 1000,
    payoutRatio: 2.0,
    winProbability: 0.4865,
  });

  const resetSimulation = () => {
    setSimulation({
      bankroll: settings.startingBankroll,
      currentBet: settings.baseBet,
      currentStep: 1,
      totalRounds: 0,
      results: [],
    });
  };

  const placeBet = (choice: 'red' | 'black') => {
    const isWin = Math.random() < settings.winProbability;
    const newRound = simulation.totalRounds + 1;
    
    let newBankroll = simulation.bankroll - simulation.currentBet;
    let newStep = simulation.currentStep;
    
    if (isWin) {
      newBankroll += simulation.currentBet * settings.payoutRatio;
      newStep = 1; // Reset sequence
    } else {
      newStep += 1; // Move to next Fibonacci number
    }
    
    const profit = newBankroll - settings.startingBankroll;
    
    const newResult = {
      round: newRound,
      bet: simulation.currentBet,
      outcome: isWin ? 'win' as const : 'loss' as const,
      bankroll: newBankroll,
      step: newStep,
      profit,
    };
    
    // Calculate next bet based on new step
    const fibonacciValue = getFibonacciStep(newStep);
    const nextBet = settings.baseBet * fibonacciValue;
    
    setSimulation({
      bankroll: newBankroll,
      currentBet: nextBet,
      currentStep: newStep,
      totalRounds: newRound,
      results: [...simulation.results, newResult].slice(-20), // Keep last 20 results
    });
  };

  const autoPlay = () => {
    // Simulate exactly 10 rounds with proper bankroll management
    const results: Array<{
      round: number;
      bet: number;
      outcome: 'win' | 'loss';
      bankroll: number;
      step: number;
      profit: number;
    }> = [];
    
    let bankroll = simulation.bankroll;
    let currentStep = simulation.currentStep;
    
    for (let round = 1; round <= 10; round++) {
      const fibonacciValue = getFibonacciStep(currentStep);
      const bet = settings.baseBet * fibonacciValue;
      
      // Only bet what we can afford, stop if bankroll is insufficient
      const actualBet = Math.min(bet, bankroll);
      
      if (actualBet <= 0 || bankroll <= 0) {
        // Cannot place bet, create a "no bet" result for remaining rounds
        results.push({
          round: simulation.totalRounds + round,
          bet: 0,
          outcome: 'loss',
          bankroll,
          step: currentStep,
          profit: bankroll - settings.startingBankroll,
        });
        continue;
      }
      
      bankroll -= actualBet;
      const isWin = Math.random() < settings.winProbability;
      
      if (isWin) {
        const winnings = actualBet * settings.payoutRatio;
        bankroll += winnings;
        currentStep = 1; // Reset to beginning
      } else {
        currentStep++; // Move to next Fibonacci number
      }
      
      const profit = bankroll - settings.startingBankroll;
      
      results.push({
        round: simulation.totalRounds + round,
        bet: actualBet,
        outcome: isWin ? 'win' : 'loss',
        bankroll,
        step: currentStep - (isWin ? 1 : 0),
        profit,
      });
    }
    
    // Calculate next bet for UI display based on final state
    const nextFibValue = getFibonacciStep(currentStep);
    const nextBet = settings.baseBet * nextFibValue;
    
    setSimulation({
      bankroll: results[results.length - 1].bankroll,
      currentBet: Math.min(nextBet, results[results.length - 1].bankroll),
      currentStep: currentStep,
      totalRounds: simulation.totalRounds + 10,
      results: [...simulation.results, ...results].slice(-30),
    });
  };

  // Helper function to get Fibonacci step value
  function getFibonacciStep(step: number): number {
    if (step <= 0) return 0;
    if (step === 1 || step === 2) return 1;
    
    let a = 1, b = 1;
    for (let i = 3; i <= step; i++) {
      const temp = a + b;
      a = b;
      b = temp;
    }
    return b;
  }

  const chartData = simulation.results.map(result => ({
    round: result.round,
    bankroll: result.bankroll,
    profit: result.profit,
  }));

  return (
    <section id="simulator" className="py-16" data-testid="betting-simulator-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Practice Simulator</h2>
          <p className="text-muted-foreground text-lg">
            Practice the Fibonacci strategy with virtual money in realistic scenarios
          </p>
        </div>

        <Card data-testid="simulator-interface">
          <CardContent className="p-8">
            {/* Simulation Controls */}
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 space-y-4 lg:space-y-0">
              <div className="flex items-center space-x-4">
                <div className="text-sm">
                  <div className="text-muted-foreground">Virtual Bankroll</div>
                  <div className="text-2xl font-bold text-primary" data-testid="text-virtual-bankroll">
                    ${simulation.bankroll.toFixed(2)}
                  </div>
                </div>
                <div className="text-sm">
                  <div className="text-muted-foreground">Current Bet</div>
                  <div className="text-xl font-bold font-mono" data-testid="text-current-bet">
                    ${simulation.currentBet.toFixed(2)}
                  </div>
                </div>
                <div className="text-sm">
                  <div className="text-muted-foreground">Sequence Step</div>
                  <div className="text-xl font-bold text-accent" data-testid="text-sequence-step">
                    {simulation.currentStep} (F{simulation.currentStep})
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <Button variant="secondary" onClick={resetSimulation} data-testid="button-reset-simulation">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset Simulation
                </Button>
                <Button variant="outline" data-testid="button-settings">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </div>
            </div>

            {/* Betting Interface */}
            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <BankrollChart data={chartData} className="chart-container" />

              <div className="space-y-4">
                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <CardTitle className="font-semibold mb-3">Current Scenario</CardTitle>
                    <div className="text-sm text-muted-foreground mb-2">European Roulette - Red/Black</div>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Win Probability:</span>
                        <span className="font-mono">48.65%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Payout Ratio:</span>
                        <span className="font-mono">2.0x</span>
                      </div>
                      <div className="flex justify-between">
                        <span>House Edge:</span>
                        <span className="font-mono text-destructive">2.7%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-2 gap-3">
                  <Button
                    className="bg-red-600 hover:bg-red-700 text-white py-4"
                    onClick={() => placeBet('red')}
                    disabled={simulation.currentBet > simulation.bankroll}
                    data-testid="button-bet-red"
                  >
                    <Square className="w-5 h-5 mb-2 mx-auto block" />
                    Bet Red
                  </Button>
                  <Button
                    className="bg-black hover:bg-gray-800 text-white py-4"
                    onClick={() => placeBet('black')}
                    disabled={simulation.currentBet > simulation.bankroll}
                    data-testid="button-bet-black"
                  >
                    <Square className="w-5 h-5 mb-2 mx-auto block" />
                    Bet Black
                  </Button>
                </div>

                <Button 
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  onClick={autoPlay}
                  disabled={simulation.currentBet > simulation.bankroll}
                  data-testid="button-auto-play"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Auto-Play 10 Rounds
                </Button>
              </div>
            </div>

            {/* Recent Results */}
            <div className="border-t border-border pt-6">
              <h4 className="text-lg font-semibold mb-4">Recent Results</h4>
              <div className="flex flex-wrap gap-2" data-testid="recent-results">
                {simulation.results.slice(-12).map((result, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-2 bg-muted rounded-lg px-3 py-2"
                    data-testid={`result-${index}`}
                  >
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      result.outcome === 'win' ? 'bg-green-600' : 'bg-red-600'
                    }`}>
                      <span className="text-white text-xs font-bold">
                        {result.outcome === 'win' ? 'W' : 'L'}
                      </span>
                    </div>
                    <span className="font-mono text-sm">${result.bet.toFixed(0)}</span>
                    <span className={`text-sm ${result.outcome === 'win' ? 'text-green-600' : 'text-red-600'}`}>
                      {result.outcome === 'win' ? '+' : '-'}${result.bet.toFixed(0)}
                    </span>
                  </div>
                ))}
                {simulation.results.length === 0 && (
                  <div className="text-muted-foreground text-sm">No results yet. Place your first bet!</div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
