import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calculator } from "lucide-react";
import { calculateStakeProgression } from "@/lib/betting-calculator";
import type { BettingCalculation } from "@/lib/betting-calculator";

export default function StrategyCalculator() {
  const [baseBet, setBaseBet] = useState(10);
  const [bankroll, setBankroll] = useState(1000);
  const [payoutRatio, setPayoutRatio] = useState(2.0);
  const [maxSteps, setMaxSteps] = useState(10);
  const [calculation, setCalculation] = useState<BettingCalculation | null>(null);

  const calculateProgression = () => {
    const result = calculateStakeProgression(baseBet, maxSteps, bankroll);
    setCalculation(result);
  };

  useEffect(() => {
    calculateProgression();
  }, [baseBet, bankroll, maxSteps]);

  return (
    <section id="calculator" className="py-16 bg-muted" data-testid="strategy-calculator-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Strategy Calculator</h2>
          <p className="text-muted-foreground text-lg">
            Calculate stake progression and potential outcomes for different scenarios
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Panel */}
          <Card data-testid="calculator-input-panel">
            <CardHeader>
              <CardTitle className="text-xl font-semibold">Strategy Parameters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="baseBet">Base Bet Amount ($)</Label>
                <Input
                  id="baseBet"
                  type="number"
                  value={baseBet}
                  onChange={(e) => setBaseBet(Number(e.target.value) || 0)}
                  min="1"
                  step="1"
                  data-testid="input-base-bet"
                />
              </div>

              <div>
                <Label htmlFor="bankroll">Starting Bankroll ($)</Label>
                <Input
                  id="bankroll"
                  type="number"
                  value={bankroll}
                  onChange={(e) => setBankroll(Number(e.target.value) || 0)}
                  min="1"
                  step="1"
                  data-testid="input-bankroll"
                />
              </div>

              <div>
                <Label htmlFor="payoutRatio">Payout Ratio (e.g., 2.0 for even money)</Label>
                <Input
                  id="payoutRatio"
                  type="number"
                  value={payoutRatio}
                  onChange={(e) => setPayoutRatio(Number(e.target.value) || 0)}
                  min="1.1"
                  max="10"
                  step="0.1"
                  data-testid="input-payout-ratio"
                />
              </div>

              <div>
                <Label htmlFor="maxSteps">Maximum Sequence Length</Label>
                <Select value={maxSteps.toString()} onValueChange={(value) => setMaxSteps(Number(value))}>
                  <SelectTrigger data-testid="select-max-steps">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10 steps</SelectItem>
                    <SelectItem value="15">15 steps</SelectItem>
                    <SelectItem value="20">20 steps</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                onClick={calculateProgression} 
                className="w-full"
                data-testid="button-calculate-progression"
              >
                <Calculator className="w-4 h-4 mr-2" />
                Calculate Progression
              </Button>
            </CardContent>
          </Card>

          {/* Results Panel */}
          <Card data-testid="calculator-results-panel">
            <CardHeader>
              <CardTitle className="text-xl font-semibold">Stake Progression</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 mb-6 max-h-64 overflow-y-auto">
                {calculation?.steps.map((step, index) => (
                  <div
                    key={index}
                    className={`
                      flex justify-between items-center py-2 px-3 rounded-lg
                      ${index < 4 ? 'bg-muted' : index === 4 ? 'bg-accent text-accent-foreground' : 'bg-muted opacity-60'}
                    `}
                    data-testid={`stake-step-${index}`}
                  >
                    <span className="font-medium">Step {step.step}</span>
                    <span className="font-mono">${step.stake.toFixed(2)}</span>
                    <span className="text-sm opacity-80">F({step.step})</span>
                  </div>
                ))}
              </div>

              {calculation && (
                <div className="border-t border-border pt-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="bg-muted rounded-lg p-3">
                      <div className="text-2xl font-bold text-primary" data-testid="text-total-risk">
                        ${calculation.totalRisk.toFixed(0)}
                      </div>
                      <div className="text-sm text-muted-foreground">Total Risk</div>
                    </div>
                    <div className="bg-muted rounded-lg p-3">
                      <div 
                        className={`text-2xl font-bold ${
                          calculation.bankrollRisk > 50 ? 'text-destructive' : 
                          calculation.bankrollRisk > 25 ? 'text-accent' : 'text-accent'
                        }`}
                        data-testid="text-bankroll-risk"
                      >
                        {calculation.bankrollRisk.toFixed(1)}%
                      </div>
                      <div className="text-sm text-muted-foreground">Bankroll Risk</div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
