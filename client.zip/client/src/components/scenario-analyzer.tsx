import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Play } from "lucide-react";
import { analyzePattern } from "@/lib/betting-calculator";

interface AnalysisResult {
  results: Array<{
    round: number;
    bet: number;
    outcome: 'win' | 'loss';
    bankroll: number;
    step: number;
    profit: number;
  }>;
  finalBankroll: number;
  totalWagered: number;
  netResult: number;
  maxDrawdown: number;
  winRate: number;
  maxSequenceLength: number;
  largestBet: number;
  riskLevel: 'low' | 'medium' | 'high';
}

const predefinedPatterns = [
  { name: "Alternating Win/Loss", pattern: "WLWLWLWL", description: "WLWLWLWL..." },
  { name: "Long Losing Streak", pattern: "LLLLLLLL", description: "LLLLLLLL..." },
  { name: "Early Win Recovery", pattern: "LLWLLWLLW", description: "LLWLLWLLW..." },
  { name: "Random Distribution", pattern: "WLLWLWLL", description: "WLLWLWLL..." },
];

export default function ScenarioAnalyzer() {
  const [selectedPattern, setSelectedPattern] = useState(predefinedPatterns[0]);
  const [customPattern, setCustomPattern] = useState("");
  const [baseBet, setBaseBet] = useState(10);
  const [startingBankroll, setStartingBankroll] = useState(1000);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isCustom, setIsCustom] = useState(false);

  const runAnalysis = () => {
    const pattern = isCustom ? customPattern : selectedPattern.pattern;
    if (!pattern) return;

    const result = analyzePattern(pattern, baseBet, startingBankroll);
    setAnalysis(result);
  };

  const patternArray = (isCustom ? customPattern : selectedPattern.pattern).split('');

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      default: return 'text-muted-foreground';
    }
  };

  const getRiskWidth = (level: string) => {
    switch (level) {
      case 'low': return '25%';
      case 'medium': return '50%';
      case 'high': return '75%';
      default: return '0%';
    }
  };

  return (
    <section id="analyzer" className="py-16 bg-muted" data-testid="scenario-analyzer-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Scenario Analyzer</h2>
          <p className="text-muted-foreground text-lg">
            Analyze different outcome patterns and their impact on your strategy
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Scenario Selection */}
          <Card data-testid="scenario-selection">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Scenario Patterns</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {predefinedPatterns.map((pattern, index) => (
                <Button
                  key={index}
                  variant={selectedPattern.name === pattern.name && !isCustom ? "default" : "outline"}
                  className="w-full text-left p-3 h-auto"
                  onClick={() => {
                    setSelectedPattern(pattern);
                    setIsCustom(false);
                  }}
                  data-testid={`pattern-${index}`}
                >
                  <div>
                    <div className="font-medium">{pattern.name}</div>
                    <div className="text-sm opacity-80">{pattern.description}</div>
                  </div>
                </Button>
              ))}
              
              <div className="space-y-2">
                <Button
                  variant={isCustom ? "default" : "outline"}
                  className="w-full text-left p-3 h-auto"
                  onClick={() => setIsCustom(true)}
                  data-testid="button-custom-pattern"
                >
                  <div>
                    <div className="font-medium">Custom Pattern</div>
                    <div className="text-sm opacity-80">Create your own</div>
                  </div>
                </Button>
                
                {isCustom && (
                  <div>
                    <Label htmlFor="customPattern">Pattern (W for Win, L for Loss)</Label>
                    <Input
                      id="customPattern"
                      value={customPattern}
                      onChange={(e) => setCustomPattern(e.target.value.toUpperCase().replace(/[^WL]/g, ''))}
                      placeholder="WLWLWL..."
                      maxLength={50}
                      data-testid="input-custom-pattern"
                    />
                  </div>
                )}
              </div>

              <div className="space-y-2 pt-4 border-t">
                <div>
                  <Label htmlFor="baseBetAnalyzer">Base Bet ($)</Label>
                  <Input
                    id="baseBetAnalyzer"
                    type="number"
                    value={baseBet}
                    onChange={(e) => setBaseBet(Number(e.target.value) || 0)}
                    min="1"
                    data-testid="input-base-bet-analyzer"
                  />
                </div>
                <div>
                  <Label htmlFor="bankrollAnalyzer">Starting Bankroll ($)</Label>
                  <Input
                    id="bankrollAnalyzer"
                    type="number"
                    value={startingBankroll}
                    onChange={(e) => setStartingBankroll(Number(e.target.value) || 0)}
                    min="1"
                    data-testid="input-bankroll-analyzer"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pattern Visualization */}
          <Card data-testid="pattern-visualization">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Pattern Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-1 mb-4">
                {patternArray.map((result, index) => (
                  <div
                    key={index}
                    className={`w-8 h-8 rounded flex items-center justify-center text-white text-xs font-bold ${
                      result === 'W' ? 'bg-green-500' : 'bg-red-500'
                    }`}
                    data-testid={`pattern-result-${index}`}
                  >
                    {result}
                  </div>
                ))}
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Total Rounds:</span>
                  <span className="font-mono" data-testid="text-total-rounds">
                    {patternArray.length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Win Rate:</span>
                  <span className="font-mono text-green-600" data-testid="text-win-rate">
                    {patternArray.length > 0 ? ((patternArray.filter(r => r === 'W').length / patternArray.length) * 100).toFixed(1) : 0}%
                  </span>
                </div>
                {analysis && (
                  <>
                    <div className="flex justify-between">
                      <span>Max Sequence:</span>
                      <span className="font-mono" data-testid="text-max-sequence">
                        {analysis.maxSequenceLength}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Wagered:</span>
                      <span className="font-mono" data-testid="text-total-wagered">
                        ${analysis.totalWagered.toFixed(2)}
                      </span>
                    </div>
                  </>
                )}
              </div>

              <Button 
                onClick={runAnalysis} 
                className="w-full bg-accent text-accent-foreground"
                disabled={patternArray.length === 0}
                data-testid="button-run-analysis"
              >
                <Play className="w-4 h-4 mr-2" />
                Run Analysis
              </Button>
            </CardContent>
          </Card>

          {/* Results Summary */}
          <Card data-testid="results-summary">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Financial Impact</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {analysis ? (
                <>
                  <div className={`border rounded-lg p-4 ${analysis.netResult >= 0 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                    <div className={`font-medium mb-1 ${analysis.netResult >= 0 ? 'text-green-800' : 'text-red-800'}`}>
                      Net Profit/Loss
                    </div>
                    <div className={`text-2xl font-bold ${analysis.netResult >= 0 ? 'text-green-600' : 'text-red-600'}`} data-testid="text-net-result">
                      {analysis.netResult >= 0 ? '+' : ''}${analysis.netResult.toFixed(2)}
                    </div>
                  </div>

                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span>Starting Bankroll:</span>
                      <span className="font-mono">${startingBankroll.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Ending Bankroll:</span>
                      <span className={`font-mono ${analysis.finalBankroll >= startingBankroll ? 'text-green-600' : 'text-red-600'}`} data-testid="text-ending-bankroll">
                        ${analysis.finalBankroll.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Maximum Drawdown:</span>
                      <span className="font-mono text-red-600" data-testid="text-max-drawdown">
                        -${analysis.maxDrawdown.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Largest Single Bet:</span>
                      <span className="font-mono" data-testid="text-largest-bet">
                        ${analysis.largestBet.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <div className="border-t border-border pt-3">
                    <div className="text-xs text-muted-foreground mb-2">Risk Assessment</div>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-muted rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            analysis.riskLevel === 'low' ? 'bg-green-500' :
                            analysis.riskLevel === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: getRiskWidth(analysis.riskLevel) }}
                        ></div>
                      </div>
                      <span className={`text-xs font-medium capitalize ${getRiskColor(analysis.riskLevel)}`} data-testid="text-risk-level">
                        {analysis.riskLevel} Risk
                      </span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Play className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>Run an analysis to see results</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
