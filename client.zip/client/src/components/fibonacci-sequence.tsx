import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, RotateCcw } from "lucide-react";
import { generateFibonacci } from "@/lib/fibonacci";

export default function FibonacciSequence() {
  const [currentLength, setCurrentLength] = useState(7);
  const [animatingIndex, setAnimatingIndex] = useState<number | null>(null);

  const fibonacciNumbers = generateFibonacci(currentLength);

  const generateNext = () => {
    if (currentLength < 15) {
      setAnimatingIndex(currentLength);
      setTimeout(() => {
        setCurrentLength(prev => prev + 1);
        setAnimatingIndex(null);
      }, 300);
    }
  };

  const reset = () => {
    setCurrentLength(2);
    setAnimatingIndex(null);
  };

  return (
    <section id="learn" className="py-16" data-testid="fibonacci-sequence-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Understanding the Fibonacci Sequence</h2>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
            The Fibonacci sequence forms the mathematical foundation of this progressive betting strategy. 
            Each number is the sum of the two preceding ones.
          </p>
        </div>

        <Card className="mb-12" data-testid="fibonacci-generator">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-xl font-semibold">Interactive Sequence Generator</CardTitle>
              <div className="flex gap-2">
                <Button 
                  onClick={generateNext} 
                  disabled={currentLength >= 15}
                  data-testid="button-generate-next"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Generate Next
                </Button>
                <Button variant="outline" onClick={reset} data-testid="button-reset-sequence">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 sm:grid-cols-6 lg:grid-cols-10 gap-4 mb-6">
              {fibonacciNumbers.map((number, index) => (
                <div
                  key={index}
                  className={`
                    bg-primary text-primary-foreground rounded-lg p-3 text-center font-mono font-bold transition-all duration-300
                    ${animatingIndex === index ? 'animate-pulse scale-110' : ''}
                    ${index === currentLength - 1 ? 'border-2 border-accent' : ''}
                  `}
                  data-testid={`fibonacci-number-${index}`}
                >
                  <div className="text-sm opacity-80">F({index + 1})</div>
                  <div className="text-lg">{number}</div>
                </div>
              ))}
              {currentLength < 15 && (
                <div className="bg-muted border-2 border-dashed border-border rounded-lg p-3 text-center">
                  <div className="text-sm text-muted-foreground">F({currentLength + 1})</div>
                  <div className="text-lg text-muted-foreground">?</div>
                </div>
              )}
            </div>

            <div className="bg-muted rounded-lg p-4">
              <div className="font-medium mb-2">Formula: F(n) = F(n-1) + F(n-2)</div>
              {currentLength >= 3 && (
                <div className="text-muted-foreground">
                  Next calculation: F({currentLength + 1}) = F({currentLength}) + F({currentLength - 1}) = {fibonacciNumbers[currentLength - 1]} + {fibonacciNumbers[currentLength - 2]} = {fibonacciNumbers[currentLength - 1] + fibonacciNumbers[currentLength - 2]}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Strategy Explanation Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="strategy-card bg-card p-6 rounded-xl border border-border" data-testid="card-progressive-system">
            <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mb-4">
              <i className="fas fa-chart-line text-primary-foreground text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold mb-3">Progressive System</h3>
            <p className="text-muted-foreground">
              Increase your bet following the Fibonacci sequence after each loss. 
              Return to the beginning after a win.
            </p>
          </div>

          <div className="strategy-card bg-card p-6 rounded-xl border border-border" data-testid="card-risk-management">
            <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mb-4">
              <i className="fas fa-shield-alt text-white text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold mb-3">Risk Management</h3>
            <p className="text-muted-foreground">
              Built-in loss limits and slower progression compared to other systems, 
              providing better bankroll protection.
            </p>
          </div>

          <div className="strategy-card bg-card p-6 rounded-xl border border-border" data-testid="card-important-warnings">
            <div className="w-12 h-12 bg-destructive rounded-lg flex items-center justify-center mb-4">
              <i className="fas fa-exclamation-triangle text-destructive-foreground text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold mb-3">Important Warnings</h3>
            <p className="text-muted-foreground">
              No betting system can overcome house edge. This tool is for educational 
              purposes only - always gamble responsibly.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
