import { generateFibonacci, getFibonacciStep } from './fibonacci';

export interface BettingCalculation {
  steps: Array<{
    step: number;
    fibonacciNumber: number;
    stake: number;
    cumulativeRisk: number;
  }>;
  totalRisk: number;
  maxBet: number;
  bankrollRisk: number;
}

export function calculateStakeProgression(
  baseBet: number,
  maxSteps: number,
  bankroll: number
): BettingCalculation {
  const fibonacci = generateFibonacci(maxSteps);
  let cumulativeRisk = 0;
  
  const steps = fibonacci.map((fibNum, index) => {
    const stake = baseBet * fibNum;
    cumulativeRisk += stake;
    
    return {
      step: index + 1,
      fibonacciNumber: fibNum,
      stake,
      cumulativeRisk,
    };
  });

  const totalRisk = cumulativeRisk;
  const maxBet = Math.max(...steps.map(s => s.stake));
  const bankrollRisk = (totalRisk / bankroll) * 100;

  return {
    steps,
    totalRisk,
    maxBet,
    bankrollRisk,
  };
}

export interface SimulationResult {
  round: number;
  bet: number;
  outcome: 'win' | 'loss';
  bankroll: number;
  step: number;
  profit: number;
}

export function simulateBetting(
  baseBet: number,
  startingBankroll: number,
  payoutRatio: number,
  winProbability: number,
  maxRounds: number = 100
): {
  results: SimulationResult[];
  finalBankroll: number;
  totalWagered: number;
  netProfit: number;
  maxDrawdown: number;
  winRate: number;
} {
  const results: SimulationResult[] = [];
  let bankroll = startingBankroll;
  let currentStep = 1;
  let totalWagered = 0;
  let wins = 0;
  let maxBankroll = startingBankroll;
  let maxDrawdown = 0;

  for (let round = 1; round <= maxRounds; round++) {
    const fibonacciValue = getFibonacciStep(currentStep);
    const bet = baseBet * fibonacciValue;
    
    if (bet > bankroll) break; // Can't place bet
    
    bankroll -= bet;
    totalWagered += bet;
    
    const isWin = Math.random() < winProbability;
    
    if (isWin) {
      const winnings = bet * payoutRatio;
      bankroll += winnings;
      currentStep = 1; // Reset to beginning
      wins++;
    } else {
      currentStep++; // Move to next Fibonacci number
    }
    
    const profit = bankroll - startingBankroll;
    
    if (bankroll > maxBankroll) {
      maxBankroll = bankroll;
    }
    
    const drawdown = maxBankroll - bankroll;
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
    }
    
    results.push({
      round,
      bet,
      outcome: isWin ? 'win' : 'loss',
      bankroll,
      step: currentStep - (isWin ? 1 : 0),
      profit,
    });
    
    if (bankroll <= 0) break; // Bankrupt
  }

  return {
    results,
    finalBankroll: bankroll,
    totalWagered,
    netProfit: bankroll - startingBankroll,
    maxDrawdown,
    winRate: wins / results.length,
  };
}

export function analyzePattern(
  pattern: string,
  baseBet: number,
  startingBankroll: number,
  payoutRatio: number = 2.0
): {
  results: SimulationResult[];
  finalBankroll: number;
  totalWagered: number;
  netResult: number;
  maxDrawdown: number;
  winRate: number;
  maxSequenceLength: number;
  largestBet: number;
  riskLevel: 'low' | 'medium' | 'high';
} {
  const results: SimulationResult[] = [];
  let bankroll = startingBankroll;
  let currentStep = 1;
  let totalWagered = 0;
  let wins = 0;
  let maxBankroll = startingBankroll;
  let maxDrawdown = 0;
  let maxSequenceLength = 1;
  let currentSequenceLength = 1;
  let largestBet = 0;

  for (let i = 0; i < pattern.length; i++) {
    const isWin = pattern[i].toLowerCase() === 'w';
    const fibonacciValue = getFibonacciStep(currentStep);
    const bet = baseBet * fibonacciValue;
    
    if (bet > largestBet) largestBet = bet;
    if (bet > bankroll) break;
    
    bankroll -= bet;
    totalWagered += bet;
    
    if (isWin) {
      const winnings = bet * payoutRatio;
      bankroll += winnings;
      currentStep = 1;
      currentSequenceLength = 1;
      wins++;
    } else {
      currentStep++;
      currentSequenceLength++;
      if (currentSequenceLength > maxSequenceLength) {
        maxSequenceLength = currentSequenceLength;
      }
    }
    
    const profit = bankroll - startingBankroll;
    
    if (bankroll > maxBankroll) {
      maxBankroll = bankroll;
    }
    
    const drawdown = maxBankroll - bankroll;
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
    }
    
    results.push({
      round: i + 1,
      bet,
      outcome: isWin ? 'win' : 'loss',
      bankroll,
      step: currentStep - (isWin ? 1 : 0),
      profit,
    });
    
    if (bankroll <= 0) break;
  }

  const bankrollRiskPercentage = (maxDrawdown / startingBankroll) * 100;
  let riskLevel: 'low' | 'medium' | 'high' = 'low';
  if (bankrollRiskPercentage > 50) riskLevel = 'high';
  else if (bankrollRiskPercentage > 25) riskLevel = 'medium';

  return {
    results,
    finalBankroll: bankroll,
    totalWagered,
    netResult: bankroll - startingBankroll,
    maxDrawdown,
    winRate: wins / results.length,
    maxSequenceLength,
    largestBet,
    riskLevel,
  };
}
