export function generateFibonacci(n: number): number[] {
  if (n <= 0) return [];
  if (n === 1) return [1];
  if (n === 2) return [1, 1];
  
  const sequence = [1, 1];
  for (let i = 2; i < n; i++) {
    sequence[i] = sequence[i-1] + sequence[i-2];
  }
  return sequence;
}

export function getFibonacciStep(step: number): number {
  if (step <= 0) return 0;
  if (step === 1 || step === 2) return 1;
  
  let a = 1, b = 1;
  for (let i = 3; i <= step; i++) {
    const temp = a + b;
    a = b;
    b = temp;
  }
  return b;
}

export function calculateNextFibonacci(current: number, previous: number): number {
  return current + previous;
}
