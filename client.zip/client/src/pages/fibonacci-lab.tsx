import { Calculator, Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import FibonacciSequence from "@/components/fibonacci-sequence";
import StrategyCalculator from "@/components/strategy-calculator";
import BettingSimulator from "@/components/betting-simulator";
import ScenarioAnalyzer from "@/components/scenario-analyzer";

export default function FibonacciLab() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      {/* Navigation Header */}
      <header className="bg-card border-b border-border sticky top-0 z-50" data-testid="navigation-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Calculator className="text-primary-foreground" size={20} />
              </div>
              <h1 className="text-xl font-bold">Fibonacci Strategy Lab</h1>
            </div>
            
            <nav className="hidden md:flex space-x-6">
              <button 
                onClick={() => scrollToSection('learn')} 
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="nav-learn"
              >
                Learn
              </button>
              <button 
                onClick={() => scrollToSection('calculator')} 
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="nav-calculator"
              >
                Calculator
              </button>
              <button 
                onClick={() => scrollToSection('simulator')} 
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="nav-simulator"
              >
                Simulator
              </button>
              <button 
                onClick={() => scrollToSection('analyzer')} 
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="nav-analyzer"
              >
                Analyzer
              </button>
            </nav>
            
            <button 
              className="md:hidden text-muted-foreground"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="mobile-menu-toggle"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
          
          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-border py-4" data-testid="mobile-menu">
              <div className="flex flex-col space-y-3">
                <button 
                  onClick={() => scrollToSection('learn')} 
                  className="text-left text-muted-foreground hover:text-foreground transition-colors"
                >
                  Learn
                </button>
                <button 
                  onClick={() => scrollToSection('calculator')} 
                  className="text-left text-muted-foreground hover:text-foreground transition-colors"
                >
                  Calculator
                </button>
                <button 
                  onClick={() => scrollToSection('simulator')} 
                  className="text-left text-muted-foreground hover:text-foreground transition-colors"
                >
                  Simulator
                </button>
                <button 
                  onClick={() => scrollToSection('analyzer')} 
                  className="text-left text-muted-foreground hover:text-foreground transition-colors"
                >
                  Analyzer
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="fibonacci-sequence py-16 text-white" data-testid="hero-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Master the Fibonacci<br />Betting Strategy
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90">
            Learn, practice, and analyze betting strategies in a risk-free environment
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-white text-primary px-8 py-3 text-lg font-medium hover:bg-opacity-90 transition-all"
              onClick={() => scrollToSection('learn')}
              data-testid="button-start-learning"
            >
              <i className="fas fa-play mr-2"></i>Start Learning
            </Button>
            <Button 
              variant="outline"
              className="border-2 border-white text-white px-8 py-3 text-lg font-medium hover:bg-white hover:text-primary transition-all"
              onClick={() => scrollToSection('simulator')}
              data-testid="button-try-simulator"
            >
              <i className="fas fa-chart-line mr-2"></i>Try Simulator
            </Button>
          </div>
        </div>
      </section>

      {/* Fibonacci Sequence Section */}
      <FibonacciSequence />

      {/* Strategy Calculator Section */}
      <StrategyCalculator />

      {/* Betting Simulator Section */}
      <BettingSimulator />

      {/* Scenario Analyzer Section */}
      <ScenarioAnalyzer />

      {/* Educational Resources */}
      <section className="py-16" data-testid="educational-resources">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Learn More</h2>
            <p className="text-muted-foreground text-lg">
              Deepen your understanding with comprehensive educational resources
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center strategy-card" data-testid="card-strategy-guide">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <i className="fas fa-book text-primary-foreground text-xl"></i>
                </div>
                <h3 className="font-semibold mb-2">Strategy Guide</h3>
                <p className="text-muted-foreground text-sm mb-4">Complete guide to Fibonacci betting system</p>
                <button className="text-primary hover:underline">Read Guide</button>
              </CardContent>
            </Card>

            <Card className="text-center strategy-card" data-testid="card-math-behind">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-accent rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <Calculator className="text-white" size={20} />
                </div>
                <h3 className="font-semibold mb-2">Math Behind It</h3>
                <p className="text-muted-foreground text-sm mb-4">Mathematical analysis and probability theory</p>
                <button className="text-primary hover:underline">Learn Math</button>
              </CardContent>
            </Card>

            <Card className="text-center strategy-card" data-testid="card-risk-awareness">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-destructive rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <i className="fas fa-exclamation-triangle text-destructive-foreground text-xl"></i>
                </div>
                <h3 className="font-semibold mb-2">Risk Awareness</h3>
                <p className="text-muted-foreground text-sm mb-4">Understanding limits and responsible gambling</p>
                <button className="text-primary hover:underline">Learn Risks</button>
              </CardContent>
            </Card>

            <Card className="text-center strategy-card" data-testid="card-historical-context">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-secondary rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <i className="fas fa-history text-secondary-foreground text-xl"></i>
                </div>
                <h3 className="font-semibold mb-2">Historical Context</h3>
                <p className="text-muted-foreground text-sm mb-4">Origins and evolution of betting systems</p>
                <button className="text-primary hover:underline">Read History</button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12" data-testid="footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <Calculator className="text-primary-foreground" size={20} />
                </div>
                <h3 className="text-xl font-bold">Fibonacci Strategy Lab</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Educational platform for learning betting strategies in a safe, risk-free environment. 
                Always gamble responsibly and never bet more than you can afford to lose.
              </p>
              <div className="bg-destructive bg-opacity-10 border border-destructive border-opacity-30 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <i className="fas fa-exclamation-triangle text-destructive mt-1"></i>
                  <div className="text-sm">
                    <div className="font-medium text-destructive mb-1">Educational Purpose Only</div>
                    <div className="text-muted-foreground">This tool is for learning and simulation only. Real gambling involves financial risk.</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Tools</h4>
              <div className="space-y-2 text-muted-foreground">
                <div><button onClick={() => scrollToSection('calculator')} className="hover:text-foreground transition-colors">Fibonacci Calculator</button></div>
                <div><button onClick={() => scrollToSection('simulator')} className="hover:text-foreground transition-colors">Risk-Free Simulator</button></div>
                <div><button onClick={() => scrollToSection('analyzer')} className="hover:text-foreground transition-colors">Scenario Analyzer</button></div>
                <div><a href="#" className="hover:text-foreground transition-colors">Strategy Comparison</a></div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <div className="space-y-2 text-muted-foreground">
                <div><a href="#" className="hover:text-foreground transition-colors">Strategy Guide</a></div>
                <div><a href="#" className="hover:text-foreground transition-colors">Mathematical Analysis</a></div>
                <div><a href="#" className="hover:text-foreground transition-colors">Responsible Gambling</a></div>
                <div><a href="#" className="hover:text-foreground transition-colors">FAQ</a></div>
              </div>
            </div>
          </div>

          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 Fibonacci Strategy Lab. Educational content for learning purposes only.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
